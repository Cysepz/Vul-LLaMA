# 目的：將 raw_dataset(多 JSON) 轉為統一格式
import os
import json
from tqdm import tqdm
from pathlib import Path
import re
import random
import argparse
import sys

def process_raw_data(input_file, output_file, processed_data):
    total_lines = 0
    filtered_lines = 0

    with open(input_file, "r", encoding="utf-8") as f:
        for line in tqdm(f, desc="Processing"):
            total_lines += 1
            raw = json.loads(line)

            # === Patch: 過濾無效資料 ===
            if not raw.get("code") or not raw["code"].strip():
                filtered_lines += 1
                continue
            if raw.get("lineNumberStart") is None or raw.get("lineNumberEnd") is None:
                filtered_lines += 1
                continue
            if raw.get("lineNumberStart") > raw.get("lineNumberEnd"):
                filtered_lines += 1
                continue
            if not raw.get("file") or not raw.get("functionName"):
                filtered_lines += 1
                continue

            code_lines = raw["code"].strip().split("\n")
            start = raw["lineNumberStart"]
            end = raw["lineNumberEnd"]
            buggy_lines = raw.get("buggy_lines", {})
            cwe_id = raw.get("cwe_id", "")
            label = raw.get("label", 0)

            line_labels = []
            line_numbers = list(range(start, end + 1))  # Inclusive range

            for lineno in line_numbers:
                if str(lineno) in buggy_lines:
                    line_labels.append(1)
                else:
                    line_labels.append(0)

            # processed_item = {
            #     "file": raw["file"],
            #     "function_name": raw["functionName"],
            #     "cwe_id": [cwe_id] if cwe_id else [],
            #     "function_label": label,
            #     "code": raw["code"].strip(),
            #     "line_numbers": line_numbers,
            #     "line_labels": line_labels,
            # }
            processed_item = dict(raw)  # 保留原始所有欄位

            # ✅ 改欄位名稱（同時刪除原本的）
            processed_item["function_name"] = processed_item.pop("functionName")
            processed_item["function_label"] = processed_item.pop("label")

            # ✅ 刪除不要的欄位
            processed_item.pop("graph", None)

            # ✅ 新增其他欄位
            processed_item["cwe_id"] = [cwe_id] if cwe_id else []
            processed_item["line_numbers"] = line_numbers
            processed_item["line_labels"] = line_labels


            processed_data.append(processed_item)

    # === 儲存過濾後資料 ===
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        raw_text = json.dumps(processed_data, indent=2, ensure_ascii=False)
        raw_text = re.sub(r'("line_numbers": \[)[\s\S]*?\]', lambda m: m.group(0).replace('\n', '').replace('  ', ''), raw_text)
        raw_text = re.sub(r'("line_labels": \[)[\s\S]*?\]', lambda m: m.group(0).replace('\n', '').replace('  ', ''), raw_text)
        f.write(raw_text)

    print(f"✅ Done! Kept {len(processed_data)} / {total_lines} items (filtered {filtered_lines} invalid entries) → Saved to {output_file}")


def split_dataset(input_path, train_ratio, val_ratio, seed, output_dir):
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    random.seed(seed)
    random.shuffle(data)

    total = len(data)
    train_end = int(total * train_ratio)
    val_end = train_end + int(total * val_ratio)

    train_data = data[:train_end]
    val_data = data[train_end:val_end]
    test_data = data[val_end:]

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    def save_cleaned_json(data, path):
        raw_text = json.dumps(data, indent=2, ensure_ascii=False)
        raw_text = re.sub(r'("line_numbers": \[)[\s\S]*?\]', lambda m: m.group(0).replace('\n', '').replace('  ', ''), raw_text)
        raw_text = re.sub(r'("line_labels": \[)[\s\S]*?\]', lambda m: m.group(0).replace('\n', '').replace('  ', ''), raw_text)
        with open(path, "w", encoding="utf-8") as f:
            f.write(raw_text)

    save_cleaned_json(train_data, f"{output_dir}/train.json")
    save_cleaned_json(val_data, f"{output_dir}/eval.json")
    save_cleaned_json(test_data, f"{output_dir}/test.json")

    print(f"✅ Done! Total: {total} samples | Train: {len(train_data)}, Val: {len(val_data)}, Test: {len(test_data)} → Saved to: {output_dir}")

def create_balanced_dataset(input_path, output_path, num_each=10000):
    """
    產生 1:1 balance dataset（例如 10000 vulnerable + 10000 non-vulnerable）
    """
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    vul_data = [item for item in data if item["function_label"] == 1]
    nonvul_data = [item for item in data if item["function_label"] == 0]

    if len(vul_data) < num_each or len(nonvul_data) < num_each:
        print(f"❌ 資料不足！目前：vul={len(vul_data)}, nonvul={len(nonvul_data)}，無法抽出 {num_each} 筆。")
        sys.exit(1)

    vul_sample = random.sample(vul_data, num_each)
    nonvul_sample = random.sample(nonvul_data, num_each)
    balanced_data = vul_sample + nonvul_sample
    random.shuffle(balanced_data)

    with open(output_path, "w", encoding="utf-8") as f:
        raw_text = json.dumps(balanced_data, indent=2, ensure_ascii=False)
        raw_text = re.sub(r'("line_numbers": \[)[\s\S]*?\]', lambda m: m.group(0).replace('\n', '').replace('  ', ''), raw_text)
        raw_text = re.sub(r'("line_labels": \[)[\s\S]*?\]', lambda m: m.group(0).replace('\n', '').replace('  ', ''), raw_text)
        f.write(raw_text)

    print(f"✅ Done! Balanced dataset created: {output_path}")


def sample_debug_dataset(input_path, train_size, eval_size, test_size, seed=42):
    output_dir = "./data/"
    train_output = os.path.join(output_dir, "train_debug.json")
    eval_output = os.path.join(output_dir, "eval_debug.json")
    test_output = os.path.join(output_dir, "test_debug.json")

    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    total_size = len(data)
    total_needed = train_size + eval_size + test_size

    if total_size < total_needed:
        raise ValueError(f"資料筆數不足：需要 {total_needed} 筆，但只有 {total_size} 筆")

    random.seed(seed)
    sampled_data = random.sample(data, total_needed)

    train_data = sampled_data[:train_size]
    eval_data = sampled_data[train_size:train_size + eval_size]
    test_data = sampled_data[train_size + eval_size:]

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    def save_json(data, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    save_json(train_data, train_output)
    save_json(eval_data, eval_output)
    save_json(test_data, test_output)

    def count_labels(data):
        vul = sum(1 for d in data if d["function_label"] == 1)
        non_vul = sum(1 for d in data if d["function_label"] == 0)
        return vul, non_vul

    train_vul, train_non = count_labels(train_data)
    eval_vul, eval_non = count_labels(eval_data)
    test_vul, test_non = count_labels(test_data)

    print(f"✅ Sampled debug dataset：Train={train_size} Eval={eval_size} Test={test_size}")
    print(f"   - Train: {train_output} | Vul: {train_vul} / {train_size} ({train_vul/train_size:.1%})")
    print(f"   - Eval : {eval_output} | Vul: {eval_vul} / {eval_size} ({eval_vul/eval_size:.1%})")
    print(f"   - Test : {test_output} | Vul: {test_vul} / {test_size} ({test_vul/test_size:.1%})")


def main():
    ## Var: Process raw data
    input_file = "data/raw_dataset.json"   # 放原始 .json 檔案的資料夾
    output_file = "data/processed_dataset.json"  # 最終儲存路徑
    processed_data = [] # 儲存所有轉換後的資料

    ## Var: Split processed data into train, val, test
    train_ratio = 0.8
    val_ratio = 0.1
    seed = 42
    output_dir = "data/"  # 儲存切分後的資料集的資料夾
    balanced_output_path = "data/balanced_dataset.json"

    # Set up argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, required=True, choices=["process", "balance", "split", "sample_debug"], 
                        help="To choose process raw data only, split processed data only, or process and then split data.")
    args = parser.parse_args()

    # Process and/or split the dataset based on the mode
    if args.mode == "process":
        process_raw_data(input_file, output_file, processed_data)
    elif args.mode == "balance": 
        create_balanced_dataset(output_file, balanced_output_path)
    elif args.mode == "split":
        split_dataset(balanced_output_path, train_ratio, val_ratio, seed, output_dir)
    elif args.mode == "sample_debug":
        sample_debug_dataset(balanced_output_path, train_size=160, eval_size=20, test_size=20, seed=seed)

if __name__ == "__main__":
    main()